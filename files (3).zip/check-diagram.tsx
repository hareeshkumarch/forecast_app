"use client";

import { motion } from "motion/react";
import { ease, viewportOnce } from "@/lib/motion";

const TOTAL = 20;
const HIDDEN = 7;
const SHOWN = TOTAL - HIDDEN;

const heights = [22, 30, 26, 38, 33, 44, 36, 48, 41, 52, 46, 58, 50, 61, 54, 66, 57, 70, 62, 74];

const rows = [
  { label: "1 · Your sales history", kind: "history" as const },
  { label: "2 · We hide the last few weeks", kind: "hidden" as const },
  { label: "3 · Then compare what we said", kind: "compare" as const },
];

export function CheckDiagram() {
  return (
    <div className="w-full">
      {rows.map((row, r) => (
        <motion.div
          key={row.label}
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={viewportOnce}
          transition={{ duration: 0.55, ease: ease.out, delay: r * 0.35 }}
          className="mb-7 last:mb-0"
        >
          <p className="mb-3 font-mono text-[0.6875rem] uppercase tracking-[0.14em] text-paper-raised/50">
            {row.label}
          </p>

          <div className="flex h-[78px] items-end gap-[3px]">
            {heights.map((h, i) => {
              const isHidden = i >= SHOWN;

              if (row.kind === "history" || !isHidden) {
                return (
                  <motion.span
                    key={i}
                    initial={{ height: 0 }}
                    whileInView={{ height: h }}
                    viewport={viewportOnce}
                    transition={{ duration: 0.4, ease: ease.out, delay: r * 0.35 + i * 0.018 }}
                    className="flex-1 bg-paper-raised/80"
                  />
                );
              }

              if (row.kind === "hidden") {
                return (
                  <motion.span
                    key={i}
                    initial={{ height: h, opacity: 1 }}
                    whileInView={{ height: h, opacity: 0.16 }}
                    viewport={viewportOnce}
                    transition={{ duration: 0.5, ease: ease.out, delay: 0.5 + (i - SHOWN) * 0.06 }}
                    className="flex-1 border border-dashed border-paper-raised/45"
                  />
                );
              }

              const predicted = h * (i % 2 === 0 ? 0.88 : 1.07);
              return (
                <span key={i} className="relative flex flex-1 flex-col justify-end">
                  <motion.span
                    initial={{ height: 0 }}
                    whileInView={{ height: predicted }}
                    viewport={viewportOnce}
                    transition={{ duration: 0.4, ease: ease.out, delay: 0.82 + (i - SHOWN) * 0.06 }}
                    style={{ backgroundColor: "var(--color-predicted-light)" }}
                    className="w-full"
                  />
                  <motion.span
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={viewportOnce}
                    transition={{ duration: 0.3, delay: 1.15 + (i - SHOWN) * 0.06 }}
                    style={{ bottom: h }}
                    className="absolute inset-x-0 h-[2px] bg-paper-raised"
                  />
                </span>
              );
            })}
          </div>
        </motion.div>
      ))}

      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={viewportOnce}
        transition={{ duration: 0.5, delay: 1.5 }}
        className="mt-6 flex flex-wrap items-center gap-x-6 gap-y-2 border-t border-white/12 pt-4 text-caption text-paper-raised/60"
      >
        <span className="flex items-center gap-2">
          <span className="inline-block size-2.5 bg-paper-raised/80" aria-hidden />
          Real sales
        </span>
        <span className="flex items-center gap-2">
          <span
            className="inline-block size-2.5"
            style={{ backgroundColor: "var(--color-predicted-light)" }}
            aria-hidden
          />
          What we predicted
        </span>
        <span className="flex items-center gap-2">
          <span className="inline-block h-[2px] w-3.5 bg-paper-raised" aria-hidden />
          What actually happened
        </span>
      </motion.div>
    </div>
  );
}
