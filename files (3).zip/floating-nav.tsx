"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { motion, useMotionValueEvent, useScroll } from "motion/react";
import { Mark } from "@/components/marketing/mark";
import { duration, ease, springSoft } from "@/lib/motion";

const sections = [
  { id: "how-it-works", label: "How it works" },
  { id: "whats-inside", label: "Features" },
  { id: "compare", label: "Compare" },
  { id: "accuracy", label: "Accuracy" },
  
];

export function FloatingNav() {
  const { scrollY } = useScroll();
  const [lifted, setLifted] = useState(false);
  const [past, setPast] = useState(false);
  const [active, setActive] = useState<string | null>(null);

  useMotionValueEvent(scrollY, "change", (v) => {
    setLifted(v > 40);
    setPast(v > 520);
  });

  useEffect(() => {
    const targets = sections
      .map((s) => document.getElementById(s.id))
      .filter((el): el is HTMLElement => el !== null);

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (visible.length > 0) setActive(visible[0].target.id);
      },
      { rootMargin: "-45% 0px -45% 0px", threshold: 0 },
    );

    targets.forEach((t) => observer.observe(t));
    return () => observer.disconnect();
  }, []);

  return (
    <div className="fixed inset-x-0 top-4 z-50 px-4 sm:px-6">
      <motion.nav
        animate={{
          backgroundColor: lifted ? "rgba(247,248,246,0.97)" : "rgba(247,248,246,0.6)",
          boxShadow: lifted
            ? "0 10px 34px -12px rgba(20,23,20,0.28), 0 1px 2px rgba(20,23,20,0.08)"
            : "0 2px 10px -6px rgba(23,21,15,0.1)",
        }}
        transition={{ duration: duration.base, ease: ease.out }}
        className="mx-auto flex w-full max-w-[80rem] items-center justify-between gap-4 border border-rule/70 px-3 py-2.5 backdrop-blur-xl sm:px-4"
      >
        <Link
          href="#top"
          aria-label="Forecast Hub, back to top"
          className="flex shrink-0 items-center gap-2.5"
        >
          <Mark size={28} />
          <span className="text-[1rem] font-bold tracking-[-0.035em] text-ink">Forecast Hub</span>
        </Link>

        <ul className="hidden items-center gap-1 md:flex">
          {sections.map((s) => {
            const on = active === s.id;
            return (
              <li key={s.id} className="relative">
                <Link
                  href={`#${s.id}`}
                  aria-current={on ? "true" : undefined}
                  className={[
                    "relative z-10 inline-flex px-3.5 py-2 text-caption transition-colors",
                    on ? "text-accent" : "text-ink-2 hover:text-ink",
                  ].join(" ")}
                >
                  {s.label}
                </Link>
                {on && (
                  <motion.span
                    layoutId="nav-pill"
                    transition={springSoft}
                    className="absolute inset-0 bg-paper-sunk"
                  />
                )}
              </li>
            );
          })}
        </ul>

        <motion.a
          href="/dashboard"
          aria-hidden={!past}
          tabIndex={past ? 0 : -1}
          animate={{ opacity: past ? 1 : 0 }}
          transition={{ duration: duration.base, ease: ease.out }}
          className="group ml-1 inline-flex shrink-0 items-center gap-2 bg-ink px-3.5 py-2.5 text-caption font-medium text-white transition-colors duration-200 hover:bg-ink-2 active:bg-ink-2 sm:px-4"
        >
          <span className="hidden sm:inline">Open dashboard</span>
          <span className="sm:hidden">Open</span>
          <svg width="13" height="13" viewBox="0 0 14 14" fill="none" aria-hidden>
            <path
              d="M2.5 7h9m0 0L8 3.5M11.5 7 8 10.5"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="transition-transform duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:translate-x-0.5"
            />
          </svg>
        </motion.a>
      </motion.nav>
    </div>
  );
}
